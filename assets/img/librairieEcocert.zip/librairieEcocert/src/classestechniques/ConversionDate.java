package classestechniques;



import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;



/**
 *
 * @author
 */
public class ConversionDate {

    /**
     * Convertit une chaîne de caractères en objet LocalDate
     *
     * @param date une chaîne de caractères comportant une date au jour/mois/année
     * @return objet LocalDate ou null si la conversion n'est pas possible
     */
    public static LocalDate stringToLocalDate(String date) {
        try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate localDate = LocalDate.parse(date, formatter);
        return localDate;
        }catch(DateTimeParseException  | NullPointerException e){
            return null;
        }

    }

    /**
     * Convertit un objet LocalDate en chaîne de caractères
     * @param date un objet LocalDate
     * @return une chaîne au format jour/mois/année ou null si la conversion n'est pas possible
     */
    public static String  localDateToString(LocalDate date) {
        try {
           DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
           return formatter.format(date);
        } catch (NullPointerException e) {
            return null;
        }

    }
    
    /**
     * Convertit une chaîne de caractères en objet LocalDate
     *
     * @param date Une date au format jour/mois/année
     * @param pattern le format dans lequel on fournit la date
     * @return objet LocalDate ou null si la conversion n'est pas possible
     */
    public static LocalDate stringToLocalDate(String date, String pattern) {
        try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        LocalDate localDate = LocalDate.parse(date, formatter);
        return localDate;
        }catch(DateTimeParseException  | NullPointerException e){
            return null;
        }

    }

    /**
     * Convertit un objet LocalDate en chaîne de caractères
     * @param date un objet LocalDate
     * @param pattern le format dans lequel on souhaite la date
     * @return une chaîne au format correspondant au pattern ou null si la conversion n'est pas possible
     */
    public static String localDateToString(LocalDate date, String pattern) {
        try {
           DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
           return formatter.format(date);
        } catch (NullPointerException e) {
            return null;
        }
    }
    /**
     * Convertit une chaîne de caractères en objet LocalDateTime
     *
     * @param date Une date au format jour/mois/année HH:MM
     * @param pattern le format dans lequel on fournit la date
     * @return objet LocalDate ou null si la conversion n'est pas possible
     */
    public static LocalDateTime stringToLocalDateTime(String date, String pattern) {
        try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);
        return localDateTime;
        }catch(DateTimeParseException  | NullPointerException e){
            return null;
        }
    }
    /**
     * Convertit un objet LocalDateTime en chaîne de caractères
     * @param date un objet LocalDateTime
     * @param pattern le format dans lequel on souhaite la date
     * @return une chaîne au format correspondant au pattern ou null si la conversion n'est pas possible
     */
    public static String localDateTimeToString(LocalDateTime date, String pattern) {
        try {
           DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
           return formatter.format(date);
        } catch (NullPointerException e) {
            return null;
        }
    }
}
