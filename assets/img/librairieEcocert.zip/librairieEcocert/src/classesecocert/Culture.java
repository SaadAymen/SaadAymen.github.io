package classesecocert;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author SIO Classe qui permet de gérer une culture.
 */
public class Culture implements Serializable {

    private int id;
    private String nomCulture;
    private List<Produit> listeProduits = new ArrayList<>();


    /**
     * Constructeur pour instancier un objet de type Culture
     * @param id identifiant de la culture
     * @param nomCulture nom de la culture
    */
    public Culture(int id, String nomCulture) {
        this.id = id;
        this.nomCulture = nomCulture;
    }

    /**
     * Constructeur pour instancier un objet de type Culture
     *
     * @param id identifiant de la culture
     * @param nomCulture nom de la culture
     * @param listeProduits liste des produits autorisés pour la culture
     */
    public Culture(int id, String nomCulture, List<Produit> listeProduits) {
        this.id = id;
        this.nomCulture = nomCulture;
        this.listeProduits = listeProduits;
    }

//<editor-fold defaultstate="collapsed" desc="Accesseurs et mutateurs">
    /**
     * Retourne l'identifiant de la culture
     *
     * @return L'identifiant de la culture
     */
    public int getId() {
        return id;
    }

    /**
     * Modifie l'identifiant de la culture
     *
     * @param id nouvel identifiant de la culture
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retourne le nom de la culture
     *
     * @return Le nom de la culture
     */
    public String getNomCulture() {
        return nomCulture;
    }

    /**
     * Modifie le nom de la culture
     *
     * @param nomCulture nom de la culture
     */
    public void setNomCulture(String nomCulture) {
        this.nomCulture = nomCulture;
    }

    /**
     * Retourne la liste des produits autorisés sur la culture
     *
     * @return La liste des produits autorisés pour la culture
     */
    public List<Produit> getListeProduits() {
        return listeProduits;
    }

    /**
     * Modifie la liste des produits autorisés sur la culture
     *
     * @param listeProduits nouvelle liste des produits autorisés sur la culture
     */
    public void setListeProduits(List<Produit> listeProduits) {
        this.listeProduits = listeProduits;
    }
//</editor-fold>

}
