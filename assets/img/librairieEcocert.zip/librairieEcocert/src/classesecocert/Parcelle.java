package classesecocert;

import classestechniques.ConversionDate;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author SIO Classe qui permet de gérer une parcelle.
 *
 */
public class Parcelle implements Serializable {

    private String reference;
    private int surface;
    private Culture laCulture;
    List<Traitement> listeTraitements = new ArrayList<>();

    /**
     * Constructeur qui permet d'instancier un objet de type Parcelle
     *
     * @param reference identifiant de la parcelle
     * @param surface surface totale de la parcelle
     * @param laCulture la culture cultivée sur la parcelle
     */
    public Parcelle(String reference, int surface, Culture laCulture) {
        this.reference = reference;
        this.surface = surface;
        this.laCulture = laCulture;
    }

    /**
     * Constructeur qui permet d'instancier un objet de type Parcelle
     *
     * @param reference identifiant de la parcelle
     * @param surface surface totale de la parcelle
     * @param laCulture la culture cultivée sur la parcelle
     * @param traitementListe Liste des traitements effectués sur la parcelle
     */
    public Parcelle(String reference, int surface, Culture laCulture, List<Traitement> traitementListe) {
        this.reference = reference;
        this.surface = surface;
        this.laCulture = laCulture;
        this.listeTraitements = traitementListe;
    }

    //<editor-fold defaultstate="collapsed" desc="Accesseurs et mutateurs">
    /**
     * Retourne la référence de la parcelle
     *
     * @return La référence de la parcelle
     */
    public String getReference() {
        return reference;
    }

    /**
     * Modifie la référence de la parcelle
     *
     * @param reference nouvelle référence de parcelle
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * Retourne la surface de la parcelle
     *
     * @return La surface de la parcelle
     */
    public int getSurface() {
        return surface;
    }

    /**
     * Modifie la surface de la parcelle
     *
     * @param surface nouvelle surface de la parcelle
     */
    public void setSurface(int surface) {
        this.surface = surface;
    }

    /**
     * Retourne la culture cultivée sur la parcelle
     *
     * @return La culture cultivée sur la parcelle
     */
    public Culture getLaCulture() {
        return laCulture;
    }

    /**
     * Modifie la culture de la parcelle
     *
     * @param laCulture nouvelle culture pour la parcelle
     */
    public void setLaCulture(Culture laCulture) {
        this.laCulture = laCulture;
    }

    /**
     * Retourne la liste des traitements effectués sur la parcelle
     *
     * @return La liste des traitements effectués sur la parcelle
     */
    public List<Traitement> getTraitementList() {
        return listeTraitements;
    }

    /**
     * Modifie la liste des traitements de la parcelle
     *
     * @param traitementListe nouvelle liste de traitements sur la parcelle
     */
    public void setTraitementList(List<Traitement> traitementListe) {
        this.listeTraitements = traitementListe;

    }
//</editor-fold>

    /**
     * Ajoute un traitement à la liste des traitements
     *
     * @param traitement traitement effectué sur la parcelle
     */
    public void ajoutTraitement(Traitement traitement) {
        listeTraitements.add(traitement);

    }

    /**
     * Extrait les produits distincts des traitements effectués
     *
     * @return la liste des produits sans doublons
     */
    public List<Produit> donneProduitsSansDoublons() {
        List<Produit> listeProduits = new ArrayList<>();
        int i;
        Boolean trouve;
        for (Traitement t : listeTraitements) {
            trouve = false;
            i = 0;
            while (i < listeProduits.size() && !trouve) {
                if (listeProduits.get(i).getId() == t.getLeProduit().getId()) {
                    trouve = true;
                }
                i++;
            }
            if (!trouve) {
                listeProduits.add(t.getLeProduit());
            }
        }
        return listeProduits;
    }

    /**
     * Calcule le cumul des dosages des traitements d'un produit effectués sur
     * la parcelle
     *
     * @param idProduit id du produit
     * @return le cumul des dosages
     */
    public double cumulDosage(int idProduit) {
        double cumul = 0;
        for (Traitement t : listeTraitements) {
            if (t.getLeProduit().getId() == idProduit) {
                cumul = cumul + t.getDosage() * surface;
            }
        }
        return cumul;
    }

    /**
     * Recherche les traitements effectués avec le produit passé en paramètre
     *
     * @param idProduit id du produit
     * @return la liste des traitements
     */
    public List<Traitement> listeTraitementsProduits(int idProduit) {
        List<Traitement> liste = new ArrayList<>();
        for (Traitement t : listeTraitements) {
            if (t.getLeProduit().getId() == idProduit) {
                liste.add(t);
            }
        }
        return liste;
    }

    /**
     * Recherche la date du dernier traitement avec le produit passé en
     * paramètre
     *
     * @param idProduit
     * @return la date du dernier traitement sous la forme jour/mois/année
     */
    public String derniereDateTraitement(int idProduit) {
        List<Traitement> list = listeTraitementsProduits(idProduit);
        LocalDate d = list.get(0).getDateTraitement();
        for (Traitement t : list) {
            if (d.isBefore(t.getDateTraitement())) {
                d = t.getDateTraitement();
            }
        }
        return ConversionDate.localDateToString(d, "dd/MM/yyyy");
    }
    
    @Override
    public String toString(){
        return "Reference : " + reference + "\nSurface :  " + surface + "\nNom de la culture : " + this.getLaCulture().getNomCulture();
    }

}
