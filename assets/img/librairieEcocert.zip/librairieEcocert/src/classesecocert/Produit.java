package classesecocert;

import java.io.Serializable;

/**
 * @author SIO Classe qui permet de gérer un produit.
 */
public class Produit implements Serializable {

    private int id;
    private String nomProduit;
    private double dosageProduit;
    private String uniteDosage;
    private String fonction;

    /**
     * Constructeur qui permet d'instancier un objet de type produit
     *
     * @param id identifiant du produit
     * @param nom nomProduit du produit
     * @param dosageProduit dosage du produit à l'hectare
     * @param uniteDosage unité du dosage
     * @param fonction utilisation du produit
     */
    public Produit(int id, String nom, double dosageProduit, String uniteDosage, String fonction) {
        this.id = id;
        this.nomProduit = nom;
        this.dosageProduit = dosageProduit;
        this.uniteDosage = uniteDosage;
        this.fonction = fonction;
    }

    //<editor-fold defaultstate="collapsed" desc="Accesseurs et mutateurs">
    /**
     * Retourne l'identifiant du produit
     *
     * @return L'identifiant du produit
     */
    public int getId() {
        return id;
    }

    /**
     * Modifie l'identifiant du produit
     *
     * @param id nouvel identifiant du produit
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retourne le nom du produit
     *
     * @return Le nom du produit
     */
    public String getNomProduit() {
        return nomProduit;
    }

    /**
     * Modifie le nom du produit
     *
     * @param nomProduit nouveau nom du produit
     */
    public void setNomProduit(String nomProduit) {
        this.nomProduit = nomProduit;
    }

    /**
     * Retourne le dosage du produit à l'hectare
     *
     * @return Le dosage du produit à l'hectare
     */
    public double getDosageProduit() {
        return dosageProduit;
    }

    /**
     * Modifie le dosage du produit à l'hectare
     *
     * @param dosageProduit nouveau dosage du produit à l'hectare
     */
    public void setDosageProduit(double dosageProduit) {
        this.dosageProduit = dosageProduit;
    }

    /**
     * Obtient l'unité du dosage
     *
     * @return L'unité du dosage
     */
    public String getUniteDosage() {
        return uniteDosage;
    }

    /**
     * Modifie l'unité de dosage
     *
     * @param uniteDosage nouvelle unité de dosage
     */
    public void setUniteDosage(String uniteDosage) {
        this.uniteDosage = uniteDosage;
    }

    /**
     * Retourne l'utilisation du produit
     *
     * @return L'utilisation du produit
     */
    public String getFonction() {
        return fonction;
    }

    /**
     * Modifie l'utilisation du produit
     *
     * @param fonction nouvelle utilisation du produit
     */
    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    //</editor-fold>
}
