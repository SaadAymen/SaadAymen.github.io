package classesecocert;

import classestechniques.ConversionDate;

import java.io.Serializable;
import java.time.LocalDate;


/**
 * @author SIO Classe qui permet de gérer un traitement.
 */
public class Traitement implements Serializable {

    private int id;
    private LocalDate dateTraitement;
    private double dosage; //dosage à l'hectare
    private String unite;
    private Produit leProduit; //produit utilisé pour le traitement

    /**
     * Constructeur pour instancier un objet de type traitement
     *
     * @param id identifiant du traitement
     * @param dateTraitement date du traitement
     * @param dosage dosage à l'hectare
     * @param unite unité du dosage
     * @param leProduit leProduit utilisé pour le traitement
     */
    public Traitement(int id, LocalDate dateTraitement, double dosage, String unite, Produit leProduit) {
        this.id = id;
        this.dateTraitement = dateTraitement;
        this.dosage = dosage;
        this.unite = unite;
        this.leProduit = leProduit;
    }

    //<editor-fold defaultstate="collapsed" desc="Accesseurs et mutateurs">
    /**
     * Retourne l'identifiant du traitement
     *
     * @return l'identifiant du traitement
     */
    public int getId() {
        return id;
    }

    /**
     * Modifie l'identifiant du traitement
     *
     * @param id nouvel identifiant du traitement
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retourne la date du traitement
     *
     * @return la date du traitement
     */
    public LocalDate getDateTraitement() {
        return dateTraitement;
    }

    /**
     * Modifie la date du traitement
     *
     * @param dateTraitement nouvelle date de traitement
     */
    public void setDateTraitement(LocalDate dateTraitement) {
        this.dateTraitement = dateTraitement;
    }

    /**
     * Retourne le dosage à l'hectare
     *
     * @return Le dosage à l'hectare
     */
    public double getDosage() {
        return dosage;
    }

    /**
     * Modifie le dosage à l'hectare
     *
     * @param dosage nouveau dosage à l'hectare
     */
    public void setDosage(double dosage) {
        this.dosage = dosage;
    }

    /**
     * Retourne l'unité de dosage
     *
     * @return L'unité de dosage
     */
    public String getUnite() {
        return unite;
    }

    /**
     * Modifie l'unité de dosage
     *
     * @param unite nouvelle unité de dosage
     */
    public void setUnite(String unite) {
        this.unite = unite;
    }

    /**
     * Retourne le produit utilisé pour le traitement
     *
     * @return Le produit utilisé pour le traitement
     */
    public Produit getLeProduit() {
        return leProduit;
    }

    /**
     * Modifie le produit utilisé pour le traitement
     *
     * @param leProduit nouveau produit utilisé pour le traitement
     */
    public void setLeProduit(Produit leProduit) {
        this.leProduit = leProduit;
    }

//</editor-fold>
    /**
     * Retourne la date du traitement sous forme de chaine de caractères
     *
     * @return Date du traitement sous la forme jour/mois/année
     */
    public String getDateTraitementString() {
        return ConversionDate.localDateToString(dateTraitement, "dd/MM/yyyy");
    }

}
